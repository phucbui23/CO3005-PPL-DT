# Generated from BKIT.g4 by ANTLR 4.11.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,12,32,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,1,0,1,
        0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,2,1,3,1,3,3,3,26,8,3,1,4,1,4,
        1,5,1,5,1,5,0,0,6,0,2,4,6,8,10,0,1,1,0,1,2,26,0,12,1,0,0,0,2,15,
        1,0,0,0,4,21,1,0,0,0,6,25,1,0,0,0,8,27,1,0,0,0,10,29,1,0,0,0,12,
        13,3,2,1,0,13,14,5,0,0,1,14,1,1,0,0,0,15,16,3,4,2,0,16,17,5,5,0,
        0,17,18,5,4,0,0,18,19,3,6,3,0,19,20,5,3,0,0,20,3,1,0,0,0,21,22,7,
        0,0,0,22,5,1,0,0,0,23,26,3,8,4,0,24,26,3,10,5,0,25,23,1,0,0,0,25,
        24,1,0,0,0,26,7,1,0,0,0,27,28,5,6,0,0,28,9,1,0,0,0,29,30,5,7,0,0,
        30,11,1,0,0,0,1,25
    ]

class BKITParser ( Parser ):

    grammarFileName = "BKIT.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'int'", "'float'", "';'", "'='" ]

    symbolicNames = [ "<INVALID>", "Int", "Flt", "Semi", "Assignment", "Id", 
                      "Integer", "Float", "Skip", "ERROR_CHAR", "UNCLOSE_STRING", 
                      "ILLEGAL_ESCAPE", "UNTERMINATED_COMMENT" ]

    RULE_program = 0
    RULE_varDeclStmt = 1
    RULE_typeInd = 2
    RULE_primaryLiteral = 3
    RULE_integerLiteral = 4
    RULE_floatLiteral = 5

    ruleNames =  [ "program", "varDeclStmt", "typeInd", "primaryLiteral", 
                   "integerLiteral", "floatLiteral" ]

    EOF = Token.EOF
    Int=1
    Flt=2
    Semi=3
    Assignment=4
    Id=5
    Integer=6
    Float=7
    Skip=8
    ERROR_CHAR=9
    UNCLOSE_STRING=10
    ILLEGAL_ESCAPE=11
    UNTERMINATED_COMMENT=12

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.11.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def varDeclStmt(self):
            return self.getTypedRuleContext(BKITParser.VarDeclStmtContext,0)


        def EOF(self):
            return self.getToken(BKITParser.EOF, 0)

        def getRuleIndex(self):
            return BKITParser.RULE_program

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = BKITParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 12
            self.varDeclStmt()
            self.state = 13
            self.match(BKITParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VarDeclStmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def typeInd(self):
            return self.getTypedRuleContext(BKITParser.TypeIndContext,0)


        def Id(self):
            return self.getToken(BKITParser.Id, 0)

        def Assignment(self):
            return self.getToken(BKITParser.Assignment, 0)

        def primaryLiteral(self):
            return self.getTypedRuleContext(BKITParser.PrimaryLiteralContext,0)


        def Semi(self):
            return self.getToken(BKITParser.Semi, 0)

        def getRuleIndex(self):
            return BKITParser.RULE_varDeclStmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVarDeclStmt" ):
                return visitor.visitVarDeclStmt(self)
            else:
                return visitor.visitChildren(self)




    def varDeclStmt(self):

        localctx = BKITParser.VarDeclStmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_varDeclStmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 15
            self.typeInd()
            self.state = 16
            self.match(BKITParser.Id)
            self.state = 17
            self.match(BKITParser.Assignment)
            self.state = 18
            self.primaryLiteral()
            self.state = 19
            self.match(BKITParser.Semi)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TypeIndContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Int(self):
            return self.getToken(BKITParser.Int, 0)

        def Flt(self):
            return self.getToken(BKITParser.Flt, 0)

        def getRuleIndex(self):
            return BKITParser.RULE_typeInd

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTypeInd" ):
                return visitor.visitTypeInd(self)
            else:
                return visitor.visitChildren(self)




    def typeInd(self):

        localctx = BKITParser.TypeIndContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_typeInd)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 21
            _la = self._input.LA(1)
            if not(_la==1 or _la==2):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PrimaryLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def integerLiteral(self):
            return self.getTypedRuleContext(BKITParser.IntegerLiteralContext,0)


        def floatLiteral(self):
            return self.getTypedRuleContext(BKITParser.FloatLiteralContext,0)


        def getRuleIndex(self):
            return BKITParser.RULE_primaryLiteral

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPrimaryLiteral" ):
                return visitor.visitPrimaryLiteral(self)
            else:
                return visitor.visitChildren(self)




    def primaryLiteral(self):

        localctx = BKITParser.PrimaryLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_primaryLiteral)
        try:
            self.state = 25
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [6]:
                self.enterOuterAlt(localctx, 1)
                self.state = 23
                self.integerLiteral()
                pass
            elif token in [7]:
                self.enterOuterAlt(localctx, 2)
                self.state = 24
                self.floatLiteral()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IntegerLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Integer(self):
            return self.getToken(BKITParser.Integer, 0)

        def getRuleIndex(self):
            return BKITParser.RULE_integerLiteral

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIntegerLiteral" ):
                return visitor.visitIntegerLiteral(self)
            else:
                return visitor.visitChildren(self)




    def integerLiteral(self):

        localctx = BKITParser.IntegerLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_integerLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 27
            self.match(BKITParser.Integer)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FloatLiteralContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def Float(self):
            return self.getToken(BKITParser.Float, 0)

        def getRuleIndex(self):
            return BKITParser.RULE_floatLiteral

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFloatLiteral" ):
                return visitor.visitFloatLiteral(self)
            else:
                return visitor.visitChildren(self)




    def floatLiteral(self):

        localctx = BKITParser.FloatLiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_floatLiteral)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 29
            self.match(BKITParser.Float)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





